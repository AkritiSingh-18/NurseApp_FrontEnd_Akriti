declare module '@env' {
  export const API_URL: string;
  export const SOCKET_URL: string;
}
